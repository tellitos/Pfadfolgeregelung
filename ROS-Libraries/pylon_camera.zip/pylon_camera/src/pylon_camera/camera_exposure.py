#!/usr/bin/env python3
import sys
import rospy
from sensor_msgs.msg import Image
import cv2 as cv 
from cv_bridge import CvBridge, CvBridgeError
import numpy as np
import rospy
from camera_control_msgs.srv import SetExposure
from camera_control_msgs.srv import SetIntegerValue

''' Node for adjust the mean brightness with the exposure time
    brightness > target -> exposure +stepsize 
    brightness < target -> exposure -stepsize 
----
Params:
    - ~light_source     int     0,1,2  
    - ~target           int      

const:
    - step_size             100
    - target_range          2.0
    - starting_exposure  5000.0
----
Publisher:
    -
Subcriber:
    - /pylon_camera_node/image_raw  Image 
ServiceProxy
    - /pylon_camera_node/set_light_source_preset
    - /pylon_camera_node/set_exposure
    - /pylon_camera_node/set_balance_white_auto
    '''
class auto_cam:

    def __init__(self):
        self.bridge = CvBridge()
        self.wait = rospy.wait_for_message("/pylon_camera_node/image_raw",Image, timeout=None)
        self.image_sub = rospy.Subscriber("/pylon_camera_node/image_raw",Image,self.callback,queue_size=1)
        self.exposer_proxy = rospy.ServiceProxy('/pylon_camera_node/set_exposure', SetExposure)
        self.light_proxy = rospy.ServiceProxy('/pylon_camera_node/set_light_source_preset', SetIntegerValue)
        self.white_balance_proxy = rospy.ServiceProxy('/pylon_camera_node/set_balance_white_auto', SetIntegerValue)
    
    def callback(self,data):
        try:
            cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            print(e)
        self.img = self.rescale_frame(cv_image,45)

    def rescale_frame(self,frame, percent=75):
        width = int(frame.shape[1] * percent/ 100)
        height = int(frame.shape[0] * percent/ 100)
        dim = (width, height)
        return cv.resize(frame, dim, interpolation =cv.INTER_AREA)

    def set_light(self,num):
        # value : 0 = Off, 1 = Daylight5000K, 2 = Daylight6500K
        x = self.light_proxy(num)
        return x

    def set_auto_white(self,num):
        # 1-> on , 0 -> Off
        x = self.light_proxy(1)
        return x

    def set_exposure(self,inte):
        x=self.exposer_proxy(inte)
        return x
        pass

    def calc_grey_mean(self):
        img_gray = cv.cvtColor(self.img, cv.COLOR_BGR2GRAY)
        mean = np.mean(img_gray)
        return mean
        pass
    
    def auto_exposure(self,wanted,range,current_exp,step):
        mean = self.calc_grey_mean()
        #print("current mean", mean)

        if current_exp <=  500 or current_exp >= 30000:
            #print("Exposure max or min")
            return current_exp,0,mean

        if mean >= (wanted  + range):
            x = self.set_exposure(current_exp-step)
            #print("Do darker")
            return x.reached_exposure ,x.success,mean

        elif mean <= (wanted -range):
            #print("Do bright")
            x = self.set_exposure(current_exp+step) 
            return x.reached_exposure ,x.success,mean
        else:
            #print("fine")
            return current_exp,0,mean
        pass

def main(args):
    rospy.init_node('auto_exposure', anonymous=True)
    ic = auto_cam()
    light_source = rospy.get_param("~light_source")
    target = rospy.get_param("~target")
    starting_exposure = 5000.0
    step_size = 100.0
    target_range =2.0

    curr_exposure = starting_exposure
    target_mean = target
    res = ic.set_light(light_source)
    res = ic.set_auto_white(2)

    ic.set_exposure(curr_exposure)
    rospy.sleep(2)

    for i in range(3000):

        expo,success,mean = ic.auto_exposure(target_mean,target_range,curr_exposure,step_size )

        #print(expo,success)
        if success == True:
           curr_exposure = expo
        else:
            rospy.loginfo("**Result**: Target mean:  %s  reached mean:  %s  Current Exposure:  %s  used Iterations: %s",target_mean,mean ,curr_exposure ,i)
            break
        if i == 2999:
            rospy.loginfo("**Result**: Target mean:  %s  not reached. current mean:  %s  Current Exposure:  %s  used Iterations: %s",target_mean,mean ,curr_exposure ,i)
        rospy.sleep(0.05)
        cv.imshow("Image",ic.img)

        cv.waitKey(33)

    cv.waitKey(33)
    rospy.sleep(2)
    cv.destroyAllWindows()

if __name__ == '__main__':
    main(sys.argv)